<div class="central-meta item">
  <div class="pit-post">
    <figure>
      <img src="images/resources/red-post1.jpg" alt="">
      <span><i class="fa fa-bolt"></i></span>
      <i class="fa fa-image"></i>
    </figure>
    <div class="pit-post-deta">
      <h4><a href="social-post-detail.html" title="">Fallon Sherrock just became the first woman to beat..</a></h4>
      <ul class="post-up-time">
        <li>
          <div class="usr-fig">
            <img src="images/resources/side-friend1.jpg" alt="">
            <a href="#" title="">p/Frank</a>
          </div>
        </li>
        <li><i class="fa fa-clock-o"></i> Feb 22, 2020</li>
        <li>By <a href="#" title="">Dewwater</a></li>
        <li>link <a href="#" title="">https://www.abc.com</a></li>
      </ul>
      <ul class="pit-opt">
        <li class="comentz" title="Comments"><i class="fa fa-comment"></i><em>2.2k</em></li>
        <li class="share-pst" title="Shares"><i class="fa fa-share-alt"></i><em>125</em></li>
        <li class="save-post" title="Save Post"><i class="fa fa-save"></i></li>
        <li class="bad-report" title="Report"><i class="fa fa-flag"></i></li>
        <li class="bane" title="Stop Post"><i class="fa fa-ban"></i></li>
        <li class="get-link" title="Get Post Link"><i class="fa fa-link"></i></li>
        <li class="smile-it" title="Give Smiles"><i class="fas fa-hammer"></i><em>Judge it</em>
          <div class="smiles-bunch">
            <span>Bean it</span>
            <span>Recommend it</span>
            <span>List it</span>
            <span>Award it</span>
          </div>
        </li>
      </ul>
    </div>
    <div class="right-pst-meta">
      <a href="#" title="">Popular</a>
      <div class="users-thumb-list">
        <a href="#" title="" data-toggle="tooltip" data-original-title="Anderw">
          <img src="images/resources/userlist-1.jpg" alt="">
        </a>
        <a href="#" title="" data-toggle="tooltip" data-original-title="frank">
          <img src="images/resources/userlist-2.jpg" alt="">
        </a>
        <a href="#" title="" data-toggle="tooltip" data-original-title="Sara">
          <img src="images/resources/userlist-3.jpg" alt="">
        </a>
        <a href="#" title="" data-toggle="tooltip" data-original-title="Amy">
          <img src="images/resources/userlist-4.jpg" alt="">
        </a>
        <a href="#" title="" data-toggle="tooltip" data-original-title="Ema">
          <img src="images/resources/userlist-5.jpg" alt="">
        </a>
        <span><a title="" href="#">24+ more</a> liked</span>
      </div>
    </div>
    <div class="number">
      <span class="plus"><i class="fa fa-angle-up"></i></span>
      <input type="text" value="0"/>
      <span class="minus"><i class="fa fa-angle-down"></i></span>

    </div>
  </div>
</div>
