<div class="wavy-wraper">
		<div class="wavy">
		  <span style="--i:1;">S</span>
		  <span style="--i:2;">M</span>
		  <span style="--i:3;">A</span>
		  <span style="--i:4;">R</span>
		  <span style="--i:5;">T    </span>
		  <span style="--i:6;">B</span>
		  <span style="--i:7;">O</span>
		  <span style="--i:8;">O</span>
		  <span style="--i:9;">K</span>
			<span style="--i:10;">.</span>
			<span style="--i:11;">.</span>
			<span style="--i:12;">.</span>
		</div>
</div>
