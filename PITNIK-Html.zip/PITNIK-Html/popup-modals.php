<!DOCTYPE html>
<html lang="en">
<head>
    <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="" />
    <meta name="keywords" content="" />
	<title>Pitnik Social Network Toolkit</title>
    <link rel="icon" href="images/fav.png" type="image/png" sizes="16x16"> 
    
    <link rel="stylesheet" href="css/main.min.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/color.css">
    <link rel="stylesheet" href="css/responsive.css">

</head>
<body>
<div class="wavy-wraper">
		<div class="wavy">
		  <span style="--i:1;">p</span>
		  <span style="--i:2;">i</span>
		  <span style="--i:3;">t</span>
		  <span style="--i:4;">n</span>
		  <span style="--i:5;">i</span>
		  <span style="--i:6;">k</span>
		  <span style="--i:7;">.</span>
		  <span style="--i:8;">.</span>
		  <span style="--i:9;">.</span>
		</div>
	</div>
<div class="theme-layout">
	
	<div class="responsive-header">
		<div class="mh-head first Sticky">
			<span class="mh-btns-left">
				<a class="" href="#menu"><i class="fa fa-align-justify"></i></a>
			</span>
			<span class="mh-text">
				<a href="newsfeed.html" title=""><img src="images/logo2.png" alt=""></a>
			</span>
			<span class="mh-btns-right">
				<a class="fa fa-sliders" href="#shoppingbag"></a>
			</span>
		</div>
		<div class="mh-head second">
			<form class="mh-form">
				<input placeholder="search" />
				<a href="#/" class="fa fa-search"></a>
			</form>
		</div>
		<nav id="menu" class="res-menu">
			<ul>
				<li><span>Home Pages</span> 
					<ul>
						<li><a href="index.html" title="">Pitnik Default</a></li>
						<li><a href="company-landing.html" title="">Company Landing</a></li>
						<li><a href="pitrest.html" title="">Pitrest</a></li>
						<li><a href="redpit.html" title="">Redpit</a></li>
						<li><a href="redpit-category.html" title="">Redpit Category</a></li>
						<li><a href="soundnik.html" title="">Soundnik</a></li>
						<li><a href="soundnik-detail.html" title="">Soundnik Single</a></li>
						<li><a href="career.html" title="">Pitjob</a></li>
						<li><a href="shop.html" title="">Shop</a></li>
						<li><a href="classified.html" title="">Classified</a></li>
						<li><a href="pitpoint.html" title="">PitPoint</a></li>
						<li><a href="pittube.html" title="">Pittube</a></li>
						<li><a href="chat-messenger.html" title="">Messenger</a></li>
					</ul>
				</li>
				<li><span>Pittube</span>
					<ul>
						<li><a href="pittube.html" title="">Pittube</a></li>
						<li><a href="pittube-detail.html" title="">Pittube single</a></li>
						<li><a href="pittube-category.html" title="">Pittube Category</a></li>
						<li><a href="pittube-channel.html" title="">Pittube Channel</a></li>
						<li><a href="pittube-search-result.html" title="">Pittube Search Result</a></li>
					</ul>
				</li>
				<li><span>PitPoint</span>
					<ul>
						<li><a href="pitpoint.html" title="">PitPoint</a></li>
						<li><a href="pitpoint-detail.html" title="">Pitpoint Detail</a></li>
						<li><a href="pitpoint-list.html" title="">Pitpoint List style</a></li>
						<li><a href="pitpoint-without-baner.html" title="">Pitpoint without Banner</a></li>
						<li><a href="pitpoint-search-result.html" title="">Pitpoint Search</a></li>
					</ul>
				</li>
				<li><span>Pitjob</span>
					<ul>
						<li><a href="career.html" title="">Pitjob</a></li>
						<li><a href="career-detail.html" title="">Pitjob Detail</a></li>
						<li><a href="career-search-result.html" title="">Job seach page</a></li>
						<li><a href="social-post-detail.html" title="">Social Post Detail</a></li>
					</ul>
				</li>
				<li><span>Timeline</span>
					<ul>
						<li><a href="timeline.html" title="">Timeline</a></li>
						<li><a href="timeline-photos.html" title="">Timeline Photos</a></li>
						<li><a href="timeline-videos.html" title="">Timeline Videos</a></li>
						<li><a href="timeline-groups.html" title="">Timeline Groups</a></li>
						<li><a href="timeline-friends.html" title="">Timeline Friends</a></li>
						<li><a href="timeline-friends2.html" title="">Timeline Friends-2</a></li>
						<li><a href="about.html" title="">Timeline About</a></li>
						<li><a href="blog-posts.html" title="">Timeline Blog</a></li>
						<li><a href="friends-birthday.html" title="">Friends' Birthday</a></li>
						<li><a href="newsfeed.html" title="">Newsfeed</a></li>
						<li><a href="search-result.html" title="">Search Result</a></li>
					</ul>
				</li>
				<li><span>Favourit Page</span>
					<ul>
						<li><a href="fav-page.html" title="">Favourit Page</a></li>
						<li><a href="fav-favers.html" title="">Fav Page Likers</a></li>
						<li><a href="fav-events.html" title="">Fav Events</a></li>
						<li><a href="fav-event-invitations.html" title="">Fav Event Invitations</a></li>
						<li><a href="event-calendar.html" title="">Event Calendar</a></li>
						<li><a href="fav-page-create.html" title="">Create New Page</a></li>
						<li><a href="price-plans.html" title="">Price Plan</a></li>
					</ul>
				</li>
				<li><span>Forum</span>
					<ul>
						<li><a href="forum.html" title="">Forum</a></li>
						<li><a href="forum-create-topic.html" title="">Forum Create Topic</a></li>
						<li><a href="forum-open-topic.html" title="">Forum Open Topic</a></li>
						<li><a href="forums-category.html" title="">Forum Category</a></li>
					</ul>
				</li>
				<li><span>Featured</span>
					<ul>
						<li><a href="chat-messenger.html" title="">Messenger (Chatting)</a></li>
						<li><a href="notifications.html" title="">Notifications</a></li>
						<li><a href="badges.html" title="">Badges</a></li>
						<li><a href="faq.html" title="">Faq's</a></li>
						<li><a href="contribution.html" title="">Contriburion Page</a></li>
						<li><a href="manage-page.html" title="">Manage Page</a></li>
						<li><a href="weather-forecast.html" title="">weather-forecast</a></li>
						<li><a href="statistics.html" title="">Statics/Analytics</a></li>
						<li><a href="shop-cart.html" title="">Shop Cart</a></li>
					</ul>
				</li>
				<li><span>Account Setting</span>
					<ul>
						<li><a href="setting.html" title="">Setting</a></li>
						<li><a href="privacy.html" title="">Privacy</a></li>
						<li><a href="support-and-help.html" title="">Support & Help</a></li>
						<li><a href="support-and-help-detail.html" title="">Support Detail</a></li>
						<li><a href="support-and-help-search-result.html" title="">Support Search</a></li>
					</ul>
				</li>
				<li><span>Authentication</span>
					<ul>
						<li><a href="login.html" title="">Login Page</a></li>
						<li><a href="register.html" title="">Register Page</a></li>
						<li><a href="logout.html" title="">Logout Page</a></li>
						<li><a href="coming-soon.html" title="">Coming Soon</a></li>
						<li><a href="error-404.html" title="">Error 404</a></li>
						<li><a href="error-404-2.html" title="">Error 404-2</a></li>
						<li><a href="error-500.html" title="">Error 500</a></li>
					</ul>
				</li>
				<li><span>Tools</span>
					<ul>
						<li><a href="typography.html" title="">Typography</a></li>
						<li><a href="popup-modals.html" title="">Popups/Modals</a></li>
						<li><a href="post-versions.html" title="">Post Versions</a></li>
						<li><a href="sliders.html" title="">Sliders / Carousel</a></li>
						<li><a href="google-map.html" title="">Google Maps</a></li>
						<li><a href="widgets.html" title="">Widgets</a></li>
					</ul>
				</li>
			</ul>
		</nav>
		<nav id="shoppingbag">
			<div>
				<div class="">
					<form method="post">
						<div class="setting-row">
							<span>use night mode</span>
							<input type="checkbox" id="nightmode"/> 
							<label for="nightmode" data-on-label="ON" data-off-label="OFF"></label>
						</div>
						<div class="setting-row">
							<span>Notifications</span>
							<input type="checkbox" id="switch2"/> 
							<label for="switch2" data-on-label="ON" data-off-label="OFF"></label>
						</div>
						<div class="setting-row">
							<span>Notification sound</span>
							<input type="checkbox" id="switch3"/> 
							<label for="switch3" data-on-label="ON" data-off-label="OFF"></label>
						</div>
						<div class="setting-row">
							<span>My profile</span>
							<input type="checkbox" id="switch4"/> 
							<label for="switch4" data-on-label="ON" data-off-label="OFF"></label>
						</div>
						<div class="setting-row">
							<span>Show profile</span>
							<input type="checkbox" id="switch5"/> 
							<label for="switch5" data-on-label="ON" data-off-label="OFF"></label>
						</div>
					</form>
					<h4 class="panel-title">Account Setting</h4>
					<form method="post">
						<div class="setting-row">
							<span>Sub users</span>
							<input type="checkbox" id="switch6" /> 
							<label for="switch6" data-on-label="ON" data-off-label="OFF"></label>
						</div>
						<div class="setting-row">
							<span>personal account</span>
							<input type="checkbox" id="switch7" /> 
							<label for="switch7" data-on-label="ON" data-off-label="OFF"></label>
						</div>
						<div class="setting-row">
							<span>Business account</span>
							<input type="checkbox" id="switch8" /> 
							<label for="switch8" data-on-label="ON" data-off-label="OFF"></label>
						</div>
						<div class="setting-row">
							<span>Show me online</span>
							<input type="checkbox" id="switch9" /> 
							<label for="switch9" data-on-label="ON" data-off-label="OFF"></label>
						</div>
						<div class="setting-row">
							<span>Delete history</span>
							<input type="checkbox" id="switch10" /> 
							<label for="switch10" data-on-label="ON" data-off-label="OFF"></label>
						</div>
						<div class="setting-row">
							<span>Expose author name</span>
							<input type="checkbox" id="switch11" /> 
							<label for="switch11" data-on-label="ON" data-off-label="OFF"></label>
						</div>
					</form>
				</div>
			</div>
		</nav>
	</div><!-- responsive header -->
	
	<div class="topbar stick">
		<div class="logo">
			<a title="" href="newsfeed.html"><img src="images/logo.png" alt=""></a>
		</div>
		<div class="top-area">
			<div class="main-menu">
				<span>
			    	<i class="fa fa-braille"></i>
			    </span>
			</div>
			<div class="top-search">
				<form method="post" class="">
					<input type="text" placeholder="Search People, Pages, Groups etc">
					<button data-ripple><i class="ti-search"></i></button>
				</form>
			</div>
			<div class="page-name">
			    <span>Popup/Modals</span>
			 </div>
			<ul class="setting-area">
				<li><a href="newsfeed.html" title="Home" data-ripple=""><i class="fa fa-home"></i></a></li>
				<li>
					<a href="" title="Friend Requests" data-ripple="">
						<i class="fa fa-user"></i><em class="bg-red">5</em>
					</a>
					<div class="dropdowns">
						<span>5 New Requests <a href="#" title="">View all Requests</a></span>
						<ul class="drops-menu">
							<li>
								<div>
									<figure>
										<img src="images/resources/thumb-2.jpg" alt="">
									</figure>
									<div class="mesg-meta">
										<h6><a href="#" title="">Loren</a></h6>
										<span><b>Amy</b> is mutule friend</span>
										<i>yesterday</i>
									</div>
									<div class="add-del-friends">
										<a href="#" title=""><i class="fa fa-heart"></i></a>
										<a href="#" title=""><i class="fa fa-trash"></i></a>
									</div>
								</div>	
							</li>
							<li>
								<div>
									<figure>
										<img src="images/resources/thumb-3.jpg" alt="">
									</figure>
									<div class="mesg-meta">
										<h6><a href="#" title="">Tina Trump</a></h6>
										<span><b>Simson</b> is mutule friend</span>
										<i>2 days ago</i>
									</div>
									<div class="add-del-friends">
										<a href="#" title=""><i class="fa fa-heart"></i></a>
										<a href="#" title=""><i class="fa fa-trash"></i></a>
									</div>
								</div>	
							</li>
							<li>
								<div>
									<figure>
										<img src="images/resources/thumb-4.jpg" alt="">
									</figure>
									<div class="mesg-meta">
										<h6><a href="#" title="">Andrew</a></h6>
										<span><b>Bikra</b> is mutule friend</span>
										<i>4 hours ago</i>
									</div>
									<div class="add-del-friends">
										<a href="#" title=""><i class="fa fa-heart"></i></a>
										<a href="#" title=""><i class="fa fa-trash"></i></a>
									</div>
								</div>
							</li>
							<li>
								<div>
									<figure>
										<img src="images/resources/thumb-5.jpg" alt="">
									</figure>
									<div class="mesg-meta">
										<h6><a href="#" title="">Dasha</a></h6>
										<span><b>Sarah</b> is mutule friend</span>
										<i>9 hours ago</i>
									</div>
									<div class="add-del-friends">
										<a href="#" title=""><i class="fa fa-heart"></i></a>
										<a href="#" title=""><i class="fa fa-trash"></i></a>
									</div>
								</div>	
							</li>
							<li>
								<div>
									<figure>
										<img src="images/resources/thumb-1.jpg" alt="">
									</figure>
									<div class="mesg-meta">
										<h6><a href="#" title="">Emily</a></h6>
										<span><b>Amy</b> is mutule friend</span>
										<i>4 hours ago</i>
									</div>
									<div class="add-del-friends">
										<a href="#" title=""><i class="fa fa-heart"></i></a>
										<a href="#" title=""><i class="fa fa-trash"></i></a>
									</div>
								</div>	
							</li>
						</ul>
						<a href="friend-requests.html" title="" class="more-mesg">View All</a>
					</div>
				</li>
				<li>
					<a href="#" title="Notification" data-ripple="">
						<i class="fa fa-bell"></i><em class="bg-purple">7</em>
					</a>
					<div class="dropdowns">
						<span>4 New Notifications <a href="#" title="">Mark all as read</a></span>
						<ul class="drops-menu">
							<li>
								<a href="notifications.html" title="">
									<figure>
										<img src="images/resources/thumb-1.jpg" alt="">
										<span class="status f-online"></span>
									</figure>
									<div class="mesg-meta">
										<h6>sarah Loren</h6>
										<span>commented on your new profile status</span>
										<i>2 min ago</i>
									</div>
								</a>
							</li>
							<li>
								<a href="notifications.html" title="">
									<figure>
										<img src="images/resources/thumb-2.jpg" alt="">
										<span class="status f-online"></span>
									</figure>
									<div class="mesg-meta">
										<h6>Jhon doe</h6>
										<span>Nicholas Grissom just became friends. Write on his wall.</span>
										<i>4 hours ago</i>
										<figure>
											<span>Today is Marina Valentine’s Birthday! wish for celebrating</span>
											<img src="images/birthday.png" alt="">
										</figure>
									</div>
								</a>
							</li>
							<li>
								<a href="notifications.html" title="">
									<figure>
										<img src="images/resources/thumb-3.jpg" alt="">
										<span class="status f-online"></span>
									</figure>
									<div class="mesg-meta">
										<h6>Andrew</h6>
										<span>commented on your photo.</span>
										<i>Sunday</i>
										<figure>
											<span>"Celebrity looks Beautiful in that outfit! We should see each"</span>
											<img src="images/resources/admin.jpg" alt="">
										</figure>
									</div>
								</a>
							</li>
							<li>
								<a href="notifications.html" title="">
									<figure>
										<img src="images/resources/thumb-4.jpg" alt="">
										<span class="status f-online"></span>
									</figure>
									<div class="mesg-meta">
										<h6>Tom cruse</h6>
										<span>nvited you to attend to his event Goo in</span>
										<i>May 19</i>
									</div>
								</a>
								<span class="tag">New</span>
							</li>
							<li>
								<a href="notifications.html" title="">
									<figure>
										<img src="images/resources/thumb-5.jpg" alt="">
										<span class="status f-online"></span>
									</figure>
									<div class="mesg-meta">
										<h6>Amy</h6>
										<span>Andrew Changed his profile picture. </span>
										<i>dec 18</i>
									</div>
								</a>
								<span class="tag">New</span>
							</li>
						</ul>
						<a href="notifications.html" title="" class="more-mesg">View All</a>
					</div>
				</li>
				<li>
					<a href="#" title="Messages" data-ripple=""><i class="fa fa-commenting"></i><em class="bg-blue">9</em></a>
					<div class="dropdowns">
						<span>5 New Messages <a href="#" title="">Mark all as read</a></span>
						<ul class="drops-menu">
							<li>
								<a class="show-mesg" href="#" title="">
									<figure>
										<img src="images/resources/thumb-1.jpg" alt="">
										<span class="status f-online"></span>
									</figure>
									<div class="mesg-meta">
										<h6>sarah Loren</h6>
										<span><i class="ti-check"></i> Hi, how r u dear ...?</span>
										<i>2 min ago</i>
									</div>
								</a>
							</li>
							<li>
								<a class="show-mesg" href="#" title="">
									<figure>
										<img src="images/resources/thumb-2.jpg" alt="">
										<span class="status f-offline"></span>
									</figure>
									<div class="mesg-meta">
										<h6>Jhon doe</h6>
										<span><i class="ti-check"></i> We’ll have to check that at the office and see if the client is on board with</span>
										<i>2 min ago</i>
									</div>
								</a>
							</li>
							<li>
								<a class="show-mesg" href="#" title="">
									<figure>
										<img src="images/resources/thumb-3.jpg" alt="">
										<span class="status f-online"></span>
									</figure>
									<div class="mesg-meta">
										<h6>Andrew</h6>
										<span> <i class="fa fa-paperclip"></i>Hi Jack's! It’s Diana, I just wanted to let you know that we have to reschedule..</span>
										<i>2 min ago</i>
									</div>
								</a>
							</li>
							<li>
								<a class="show-mesg" href="#" title="">
									<figure>
										<img src="images/resources/thumb-4.jpg" alt="">
										<span class="status f-offline"></span>
									</figure>
									<div class="mesg-meta">
										<h6>Tom cruse</h6>
										<span><i class="ti-check"></i> Great, I’ll see you tomorrow!.</span>
										<i>2 min ago</i>
									</div>
								</a>
								<span class="tag">New</span>
							</li>
							<li>
								<a class="show-mesg" href="#" title="">
									<figure>
										<img src="images/resources/thumb-5.jpg" alt="">
										<span class="status f-away"></span>
									</figure>
									<div class="mesg-meta">
										<h6>Amy</h6>
										<span><i class="fa fa-paperclip"></i> Sed ut perspiciatis unde omnis iste natus error sit </span>
										<i>2 min ago</i>
									</div>
								</a>
								<span class="tag">New</span>
							</li>
						</ul>
						<a href="chat-messenger.html" title="" class="more-mesg">View All</a>
					</div>
				</li>
				<li><a href="#" title="Languages" data-ripple=""><i class="fa fa-globe"></i><em>EN</em></a>
					<div class="dropdowns languages">
						<div data-gutter="10" class="row">
							<div class="col-md-3">
							  <ul class="dropdown-meganav-select-list-lang">
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/UK.png">English(UK)
								  </a>
								</li>
								<li class="active">
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/US.png">English(US)
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/DE.png">Deutsch
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/NED.png">Nederlands
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/FR.png">Français
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/SP.png">Español
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/ARG.png">Español (AR)
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/IT.png">Italiano
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/PT.png">Português (PT)
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/BR.png">Português (BR)
								  </a>
								</li>

							  </ul>
							</div>
							<div class="col-md-3">
							  <ul class="dropdown-meganav-select-list-lang">
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/FIN.png">Suomi
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/SW.png">Svenska
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/DEN.png">Dansk
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/CZ.png">Čeština
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/HUN.png">Magyar
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/ROM.png">Română
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/JP.png">日本語
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/CN.png">简体中文
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/PL.png">Polski
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/GR.png">Ελληνικά
								  </a>
								</li>

							  </ul>
							</div>
							<div class="col-md-3">
							  <ul class="dropdown-meganav-select-list-lang">
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/TUR.png">Türkçe
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/BUL.png">Български
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/ARB.png">العربية
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/KOR.png">한국어
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/ISR.png">עברית
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/LAT.png">Latviski
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/UKR.png">Українська
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/IND.png">Bahasa Indonesia
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/MAL.png">Bahasa Malaysia
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/TAI.png">ภาษาไทย
								  </a>
								</li>

							  </ul>
							</div>
							<div class="col-md-3">
							  <ul class="dropdown-meganav-select-list-lang">
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/CRO.png">Hrvatski
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/LIT.png">Lietuvių
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/SLO.png">Slovenčina
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/SERB.png">Srpski
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/SLOVE.png">Slovenščina
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/NAM.png">Tiếng Việt
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/PHI.png">Filipino
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/ICE.png">Íslenska
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/EST.png">Eesti
								  </a>
								</li>
								<li>
								  <a href="#">
									<img title="Image Title" alt="Image Alternative text" src="images/flags/RU.png">Русский
								  </a>
								</li>
							  </ul>
							</div>
						  </div>
					</div>
				</li>
				<li><a href="#" title="Help" data-ripple=""><i class="fa fa-question-circle"></i></a>
					<div class="dropdowns helps">
						<span>Quick Help</span>
						<form method="post">
							<input type="text" placeholder="How can we help you?">
						</form>
						<span>Help with this page</span>
						<ul class="help-drop">
							<li><a href="forum.html" title=""><i class="fa fa-book"></i>Community & Forum</a></li>
							<li><a href="faq.html" title=""><i class="fa fa-question-circle-o"></i>FAQs</a></li>
							<li><a href="career.html" title=""><i class="fa fa-building-o"></i>Carrers</a></li>
							<li><a href="privacy.html" title=""><i class="fa fa-pencil-square-o"></i>Terms & Policy</a></li>
							<li><a href="#" title=""><i class="fa fa-map-marker"></i>Contact</a></li>
							<li><a href="#" title=""><i class="fa fa-exclamation-triangle"></i>Report a Problem</a></li>
						</ul>
					</div>
				</li>
			</ul>
			<div class="user-img">
				<h5>Jack Carter</h5>
				<img src="images/resources/admin.jpg" alt="">
				<span class="status f-online"></span>
				<div class="user-setting">
					<span class="seting-title">Chat setting <a href="#" title="">see all</a></span>
					<ul class="chat-setting">
						<li><a href="#" title=""><span class="status f-online"></span>online</a></li>
						<li><a href="#" title=""><span class="status f-away"></span>away</a></li>
						<li><a href="#" title=""><span class="status f-off"></span>offline</a></li>
					</ul>
					<span class="seting-title">User setting <a href="#" title="">see all</a></span>
					<ul class="log-out">
						<li><a href="about.html" title=""><i class="ti-user"></i> view profile</a></li>
						<li><a href="setting.html" title=""><i class="ti-pencil-alt"></i>edit profile</a></li>
						<li><a href="#" title=""><i class="ti-target"></i>activity log</a></li>
						<li><a href="setting.html" title=""><i class="ti-settings"></i>account setting</a></li>
						<li><a href="logout.html" title=""><i class="ti-power-off"></i>log out</a></li>
					</ul>
				</div>
			</div>
			<span class="ti-settings main-menu" data-ripple=""></span>
		</div>
		<nav>
			<ul class="nav-list">
				<li><a class="" href="#" title=""><i class="fa fa-home"></i> Home Pages</a>
					<ul>
						<li><a href="index.html" title="">Pitnik Default</a></li>
						<li><a href="company-landing.html" title="">Company Landing</a></li>
						<li><a href="pitrest.html" title="">Pitrest</a></li>
						<li><a href="redpit.html" title="">Redpit</a></li>
						<li><a href="redpit-category.html" title="">Redpit Category</a></li>
						<li><a href="soundnik.html" title="">Soundnik</a></li>
						<li><a href="soundnik-detail.html" title="">Soundnik Single</a></li>
						<li><a href="career.html" title="">Pitjob</a></li>
						<li><a href="shop.html" title="">Shop</a></li>
						<li><a href="classified.html" title="">Classified</a></li>
						<li><a href="pitpoint.html" title="">PitPoint</a></li>
						<li><a href="pittube.html" title="">Pittube</a></li>
						<li><a href="chat-messenger.html" title="">Messenger</a></li>
					</ul>
				</li>
				<li><a class="" href="#" title=""><i class="fa fa-film"></i> Pittube</a>
					<ul>
						<li><a href="pittube.html" title="">Pittube</a></li>
						<li><a href="pittube-detail.html" title="">Pittube single</a></li>
						<li><a href="pittube-category.html" title="">Pittube Category</a></li>
						<li><a href="pittube-channel.html" title="">Pittube Channel</a></li>
						<li><a href="pittube-search-result.html" title="">Pittube Search Result</a></li>
					</ul>
				</li>
				<li><a class="" href="#" title=""><i class="fa fa-female"></i> PitPoint</a>
					<ul>
						<li><a href="pitpoint.html" title="">PitPoint</a></li>
						<li><a href="pitpoint-detail.html" title="">Pitpoint Detail</a></li>
						<li><a href="pitpoint-list.html" title="">Pitpoint List style</a></li>
						<li><a href="pitpoint-without-baner.html" title="">Pitpoint without Banner</a></li>
						<li><a href="pitpoint-search-result.html" title="">Pitpoint Search</a></li>
					</ul>
				</li>
				<li><a class="" href="#" title=""><i class="fa fa-graduation-cap"></i> Pitjob</a>
					<ul>
						<li><a href="career.html" title="">Pitjob</a></li>
						<li><a href="career-detail.html" title="">Pitjob Detail</a></li>
						<li><a href="career-search-result.html" title="">Job seach page</a></li>
						<li><a href="social-post-detail.html" title="">Social Post Detail</a></li>
					</ul>
				</li>
				<li><a class="" href="#" title=""><i class="fa fa-repeat"></i> Timeline</a>
					<ul>
						<li><a href="timeline.html" title="">Timeline</a></li>
						<li><a href="timeline-photos.html" title="">Timeline Photos</a></li>
						<li><a href="timeline-videos.html" title="">Timeline Videos</a></li>
						<li><a href="timeline-groups.html" title="">Timeline Groups</a></li>
						<li><a href="timeline-friends.html" title="">Timeline Friends</a></li>
						<li><a href="timeline-friends2.html" title="">Timeline Friends-2</a></li>
						<li><a href="about.html" title="">Timeline About</a></li>
						<li><a href="blog-posts.html" title="">Timeline Blog</a></li>
						<li><a href="friends-birthday.html" title="">Friends' Birthday</a></li>
						<li><a href="newsfeed.html" title="">Newsfeed</a></li>
						<li><a href="search-result.html" title="">Search Result</a></li>
					</ul>
				</li>
				<li><a class="" href="#" title=""><i class="fa fa-heart"></i> Favourit Page</a>
					<ul>
						<li><a href="fav-page.html" title="">Favourit Page</a></li>
						<li><a href="fav-favers.html" title="">Fav Page Likers</a></li>
						<li><a href="fav-events.html" title="">Fav Events</a></li>
						<li><a href="fav-event-invitations.html" title="">Fav Event Invitations</a></li>
						<li><a href="event-calendar.html" title="">Event Calendar</a></li>
						<li><a href="fav-page-create.html" title="">Create New Page</a></li>
						<li><a href="price-plans.html" title="">Price Plan</a></li>
					</ul>
				</li>
				<li><a class="" href="#" title=""><i class="fa fa-forumbee"></i> Forum</a>
					<ul>
						<li><a href="forum.html" title="">Forum</a></li>
						<li><a href="forum-create-topic.html" title="">Forum Create Topic</a></li>
						<li><a href="forum-open-topic.html" title="">Forum Open Topic</a></li>
						<li><a href="forums-category.html" title="">Forum Category</a></li>
					</ul>
				</li>
				<li><a class="" href="#" title=""><i class="fa fa-star-o"></i> Featured</a>
					<ul>
						<li><a href="chat-messenger.html" title="">Messenger (Chatting)</a></li>
						<li><a href="notifications.html" title="">Notifications</a></li>
						<li><a href="badges.html" title="">Badges</a></li>
						<li><a href="faq.html" title="">Faq's</a></li>
						<li><a href="contribution.html" title="">Contriburion Page</a></li>
						<li><a href="manage-page.html" title="">Manage Page</a></li>
						<li><a href="weather-forecast.html" title="">weather-forecast</a></li>
						<li><a href="statistics.html" title="">Statics/Analytics</a></li>
						<li><a href="shop-cart.html" title="">Shop Cart</a></li>
					</ul>
				</li>
				<li><a class="" href="#" title=""><i class="fa fa-gears"></i> Account Setting</a>
					<ul>
						<li><a href="setting.html" title="">Setting</a></li>
						<li><a href="privacy.html" title="">Privacy</a></li>
						<li><a href="support-and-help.html" title="">Support & Help</a></li>
						<li><a href="support-and-help-detail.html" title="">Support Detail</a></li>
						<li><a href="support-and-help-search-result.html" title="">Support Search</a></li>
					</ul>
				</li>
				<li><a class="" href="#" title=""><i class="fa fa-lock"></i> Authentication</a>
					<ul>
						<li><a href="login.html" title="">Login Page</a></li>
						<li><a href="register.html" title="">Register Page</a></li>
						<li><a href="logout.html" title="">Logout Page</a></li>
						<li><a href="coming-soon.html" title="">Coming Soon</a></li>
						<li><a href="error-404.html" title="">Error 404</a></li>
						<li><a href="error-404-2.html" title="">Error 404-2</a></li>
						<li><a href="error-500.html" title="">Error 500</a></li>
					</ul>
				</li>
				<li><a class="" href="#" title=""><i class="fa fa-wrench"></i> Tools</a>
					<ul>
						<li><a href="typography.html" title="">Typography</a></li>
						<li><a href="popup-modals.html" title="">Popups/Modals</a></li>
						<li><a href="post-versions.html" title="">Post Versions</a></li>
						<li><a href="sliders.html" title="">Sliders / Carousel</a></li>
						<li><a href="google-map.html" title="">Google Maps</a></li>
						<li><a href="widgets.html" title="">Widgets</a></li>
					</ul>
				</li>
			</ul>
			
		</nav><!-- nav menu -->
	</div><!-- topbar -->
		
	<section>
		<div class="page-header">
			<div class="header-inner">
				<h2>Modal and Popup</h2>
				<p>
					Welcome to Pitnik Social Network. Here you’ll find all the Modal and popups using ready made elemets as you want. you can use to show on your custom pages.
				</p>
			</div>
			<figure><img src="images/resources/baner-typography.png" alt=""></figure>
		</div>
	</section><!-- sub header -->
	
	<section>
		<div class="gap gray-bg">
			<div class="container">
				<div class="row" id="page-contents">
					<div class="offset-lg-1 col-lg-10">
						<div class="modalz-popups">
							<div class="row remove-ext">
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box">
										<button type="button" class="main-btn2" data-toggle="modal" data-target="#img-comt">Image with comments </button>
									</div>	
								</div>
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box">
										<button type="button" class="main-btn2" data-toggle="modal" data-target="#blog-popup">Blog Popup </button>
									</div>	
								</div>
								
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box">
										<button type="button" class="main-btn2" data-toggle="modal" data-target="#faq-popup">Ask Question </button>
									</div>	
								</div>
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box">
										<span class="modl-box create-pst">
											Create New Post
										</span>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box">
										<span class="modl-box share-pst">
											Post Sharing
										</span>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box">
										<span class="modl-box bad-report">
											Send Post Report
										</span>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box">
										<span class="modl-box send-mesg">
											Send Direct Message
										</span>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box">
										<span class="modl-box video-call">
											Audio Video Call
										</span>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box ">
										<span class="modl-box item-upload">
											Create Friends Group
										</span>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box ">
										<span class="modl-box item-upload album">
											Upload Photo Or Album
										</span>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box ">
										<span class="modl-box user-add">
											Login / Add Account
										</span>
									</div>
								</div>
								<div class="col-lg-4 col-md-4 col-sm-4">
									<div class="pop-box ">
										<span class="modl-box event-title">
											<h4>Event Detail Popup</h4>
										</span>
									</div>
								</div>
								<div class="col-lg-12">
									<div class="central-meta">
										<h3 class="title2">Bootstrap Fading Modal</h3>
										  <p>Add the "fade" class to the modal container if you want the modal to fade in on open and fade out on close.</p>
										<!-- Button to Open the Modal -->
										<div class="row remove-ext">
											<div class="col-lg-4 col-md-4 col-sm-4">
												<div class="pop-box">
													<button type="button" class="main-btn2" data-toggle="modal" data-target="#myModal">Normal Modal</button>
												</div>
											</div>
											<div class="col-lg-4 col-md-4 col-sm-4">
												<div class="pop-box">
													<button type="button" class="main-btn2" data-toggle="modal" data-target="#myModalsmall">Small Modal</button>
												</div>
											</div>
											<div class="col-lg-4 col-md-4 col-sm-4">
												<div class="pop-box">
													<button type="button" class="main-btn2" data-toggle="modal" data-target="#myModalscroll">With Scroll Modal</button>
												</div>	
											</div>
										</div>
										
										<div class="modal fade" id="myModal">
											<div class="modal-dialog">
											  <div class="modal-content">

												<!-- Modal Header -->
												<div class="modal-header">
												  <h4 class="modal-title">Modal Heading</h4>
												  <button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>

												<!-- Modal body -->
												<div class="modal-body">
												  Modal body..
												</div>

												<!-- Modal footer -->
												<div class="modal-footer">
												  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>
											  </div>
											</div>
										</div><!-- fade Modal -->
										
										<div class="modal fade" id="myModalsmall">
											<div class="modal-dialog modal-sm">
											  <div class="modal-content">

												<!-- Modal Header -->
												<div class="modal-header">
												  <h4 class="modal-title">Modal Heading</h4>
												  <button type="button" class="close" data-dismiss="modal">&times;</button>
												</div>

												<!-- Modal body -->
												<div class="modal-body">
												  Modal body..
												</div>

												<!-- Modal footer -->
												<div class="modal-footer">
												  <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
												</div>

											  </div>
											</div>
										</div><!-- Small Modal -->
										
									    <div class="modal fade" id="myModalscroll">
											<div class="modal-dialog">
											  <div class="modal-content">

												<!-- Modal Header -->
												<div class="modal-header">
												  <h4 class="modal-title">Modal Heading</h4>
												  <button type="button" class="close" data-dismiss="modal">×</button>
												</div>

												<!-- Modal body -->
												<div class="modal-body">
												  <h5>Some text to enable scrolling..</h5>
												  <p>Some text to enable scrolling.. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
												  <p>Some text to enable scrolling.. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>

												  <p>Some text to enable scrolling.. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.</p>
												</div>

												<!-- Modal footer -->
												<div class="modal-footer">
												  <button type="button" class="btn btn-danger" data-dismiss="modal">Close</button>
												</div>

											  </div>
											</div>
									  </div><!-- The Scrolling Modal -->
									</div>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
	</section>

	<footer>
		<div class="container">
			<div class="row">
				<div class="col-lg-4 col-md-4">
					<div class="widget">
						<div class="foot-logo">
							<div class="logo">
								<a href="index.html" title=""><img src="images/logo2.png" alt=""></a>
							</div>	
							<p>
								The trio took this simple idea and built it into the world’s leading carpooling platform.
							</p>
						</div>
						<ul class="location">
							<li>
								<i class="fa fa-map-marker"></i>
								<p>33 new montgomery st.750 san francisco, CA USA 94105.</p>
							</li>
							<li>
								<i class="fa fa-phone"></i>
								<p>+1-56-346 345</p>
							</li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-6">
					<div class="widget">
						<div class="widget-title"><h4>follow</h4></div>
						<ul class="list-style">
							<li><i class="fa fa-facebook-square"></i> <a href="https://web.facebook.com/shopcircut/" title="">facebook</a></li>
							<li><i class="fa fa-twitter-square"></i><a href="https://twitter.com/login?lang=en" title="">twitter</a></li>
							<li><i class="fa fa-instagram"></i><a href="https://www.instagram.com/?hl=en" title="">instagram</a></li>
							<li><i class="fa fa-google-plus-square"></i> <a href="https://plus.google.com/discover" title="">Google+</a></li>
							<li><i class="fa fa-pinterest-square"></i> <a href="https://www.pinterest.com/" title="">Pintrest</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-6">
					<div class="widget">
						<div class="widget-title"><h4>Navigate</h4></div>
						<ul class="list-style">
							<li><a href="about.html" title="">about us</a></li>
							<li><a href="contact.html" title="">contact us</a></li>
							<li><a href="terms.html" title="">terms & Conditions</a></li>
							<li><a href="#" title="">RSS syndication</a></li>
							<li><a href="sitemap.html" title="">Sitemap</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-6">
					<div class="widget">
						<div class="widget-title"><h4>useful links</h4></div>
						<ul class="list-style">
							<li><a href="#" title="">leasing</a></li>
							<li><a href="#" title="">submit route</a></li>
							<li><a href="#" title="">how does it work?</a></li>
							<li><a href="#" title="">agent listings</a></li>
							<li><a href="#" title="">view All</a></li>
						</ul>
					</div>
				</div>
				<div class="col-lg-2 col-md-4 col-sm-6">
					<div class="widget">
						<div class="widget-title"><h4>download apps</h4></div>
						<ul class="colla-apps">
							<li><a href="https://play.google.com/store?hl=en" title=""><i class="fa fa-android"></i>android</a></li>
							<li><a href="https://www.apple.com/lae/ios/app-store/" title=""><i class="ti-apple"></i>iPhone</a></li>
							<li><a href="https://www.microsoft.com/store/apps" title=""><i class="fa fa-windows"></i>Windows</a></li>
						</ul>
					</div>
				</div>
			</div>
		</div>
	</footer><!-- footer -->
	
	<div class="bottombar">
		<div class="container">
			<div class="row">
				<div class="col-md-12">
					<span class="copyright">© Pitnik 2020. All rights reserved.</span>
					<i><img src="images/credit-cards.png" alt=""></i>
				</div>
			</div>
		</div>
	</div><!-- Bottam bar -->
</div>
	<div class="side-panel">
		<h4 class="panel-title">General Setting</h4>
		<form method="post">
			<div class="setting-row">
				<span>use night mode</span>
				<input type="checkbox" id="nightmode1"/> 
				<label for="nightmode1" data-on-label="ON" data-off-label="OFF"></label>
			</div>
			<div class="setting-row">
				<span>Notifications</span>
				<input type="checkbox" id="switch22" /> 
				<label for="switch22" data-on-label="ON" data-off-label="OFF"></label>
			</div>
			<div class="setting-row">
				<span>Notification sound</span>
				<input type="checkbox" id="switch33" /> 
				<label for="switch33" data-on-label="ON" data-off-label="OFF"></label>
			</div>
			<div class="setting-row">
				<span>My profile</span>
				<input type="checkbox" id="switch44" /> 
				<label for="switch44" data-on-label="ON" data-off-label="OFF"></label>
			</div>
			<div class="setting-row">
				<span>Show profile</span>
				<input type="checkbox" id="switch55" /> 
				<label for="switch55" data-on-label="ON" data-off-label="OFF"></label>
			</div>
		</form>
		<h4 class="panel-title">Account Setting</h4>
		<form method="post">
			<div class="setting-row">
				<span>Sub users</span>
				<input type="checkbox" id="switch66" /> 
				<label for="switch66" data-on-label="ON" data-off-label="OFF"></label>
			</div>
			<div class="setting-row">
				<span>personal account</span>
				<input type="checkbox" id="switch77" /> 
				<label for="switch77" data-on-label="ON" data-off-label="OFF"></label>
			</div>
			<div class="setting-row">
				<span>Business account</span>
				<input type="checkbox" id="switch88" /> 
				<label for="switch88" data-on-label="ON" data-off-label="OFF"></label>
			</div>
			<div class="setting-row">
				<span>Show me online</span>
				<input type="checkbox" id="switch99" /> 
				<label for="switch99" data-on-label="ON" data-off-label="OFF"></label>
			</div>
			<div class="setting-row">
				<span>Delete history</span>
				<input type="checkbox" id="switch101" /> 
				<label for="switch101" data-on-label="ON" data-off-label="OFF"></label>
			</div>
			<div class="setting-row">
				<span>Expose author name</span>
				<input type="checkbox" id="switch111" /> 
				<label for="switch111" data-on-label="ON" data-off-label="OFF"></label>
			</div>
		</form>
	</div><!-- side panel -->
	
	<div class="popup-wraper">
		<div class="popup">
			<span class="popup-closed"><i class="ti-close"></i></span>
			<div class="popup-meta">
				<div class="popup-head">
					<h5>Create New Post</h5>
				</div>
				<div class="postbox">
				<div class="new-postbox">
					<figure>
						<img src="images/resources/admin.jpg" alt="">
					</figure>
					<div class="newpst-input">
						<form method="post">
							<textarea rows="2" placeholder="Share some what you are thinking?"></textarea>
						</form>
					</div>
					<div class="attachments">
						<ul>
							<li>
								<span class="add-loc">
									<i class="fa fa-map-marker"></i>
								</span>
							</li>
							<li>
								<i class="fa fa-music"></i>
								<label class="fileContainer">
									<input type="file">
								</label>
							</li>
							<li>
								<i class="fa fa-image"></i>
								<label class="fileContainer">
									<input type="file">
								</label>
							</li>
							<li>
								<i class="fa fa-video-camera"></i>
								<label class="fileContainer">
									<input type="file">
								</label>
							</li>
							<li>
								<i class="fa fa-camera"></i>
								<label class="fileContainer">
									<input type="file">
								</label>
							</li>
							<li class="preview-btn">
								<button class="post-btn-preview" type="submit" data-ripple="">Preview</button>
							</li>
						</ul>
						<button class="post-btn" type="submit" data-ripple="">Post</button>
					</div>
					<div class="add-location-post">
						<span>Drag map point to selected area</span>
						<div class="row">
							<div class="col-lg-6">
								<label class="control-label">Lat :</label>
								<input type="text" class="" id="us3-lat" />
							</div>
							<div class="col-lg-6">
								<label>Long :</label>
								<input type="text" class="" id="us3-lon" />
							</div>
						</div>
						<!-- map -->
						<div id="us3"></div>
					</div>
				</div>	
			</div><!-- add post new box -->
			</div>	
		</div>
	</div><!-- create post popup -->
	
	<div class="popup-wraper1">
		<div class="popup direct-mesg">
			<span class="popup-closed"><i class="ti-close"></i></span>
			<div class="popup-meta">
				<div class="popup-head">
					<h5>Send Message</h5>
				</div>
				<div class="send-message">
					<form method="post" class="c-form">
						<input type="text" placeholder="Sophia">
						<textarea placeholder="Write Message"></textarea>
						<button type="submit" class="main-btn">Send</button>
					</form>
					<div class="add-smiles">
						<div class="uploadimage">
							<i class="fa fa-image"></i>
							<label class="fileContainer">
								<input type="file">
							</label>
						</div>
						<span title="add icon" class="em em-expressionless"></span>
						<div class="smiles-bunch">
							<i class="em em---1"></i>
							<i class="em em-smiley"></i>
							<i class="em em-anguished"></i>
							<i class="em em-laughing"></i>
							<i class="em em-angry"></i>
							<i class="em em-astonished"></i>
							<i class="em em-blush"></i>
							<i class="em em-disappointed"></i>
							<i class="em em-worried"></i>
							<i class="em em-kissing_heart"></i>
							<i class="em em-rage"></i>
							<i class="em em-stuck_out_tongue"></i>
						</div>
					</div>
					
				</div>
			</div>
		</div>
	</div><!-- send message popup -->
	
	<div class="popup-wraper2">
		<div class="popup post-sharing">
			<span class="popup-closed"><i class="ti-close"></i></span>
			<div class="popup-meta">
				<div class="popup-head">
					<select data-placeholder="Share to friends..." multiple class="chosen-select multi">
						<option>Share in your feed</option>
						<option>Share in friend feed</option>
						<option>Share in a page</option>
						<option>Share in a group</option>
						<option>Share in message</option>
					</select>
					<div class="post-status">
						<span><i class="fa fa-globe"></i></span>
						<ul>
							<li><a href="#" title=""><i class="fa fa-globe"></i> Post Globaly</a></li>
							<li><a href="#" title=""><i class="fa fa-user"></i> Post Private</a></li>
							<li><a href="#" title=""><i class="fa fa-user-plus"></i> Post Friends</a></li>
						</ul>
					</div>
				</div>
				<div class="postbox">
					<div class="post-comt-box">
						<form method="post">
							<input type="text" placeholder="Search Friends, Pages, Groups, etc....">
							<textarea placeholder="Say something about this..."></textarea>
							<div class="add-smiles">
								<span title="add icon" class="em em-expressionless"></span>
								<div class="smiles-bunch">
									<i class="em em---1"></i>
									<i class="em em-smiley"></i>
									<i class="em em-anguished"></i>
									<i class="em em-laughing"></i>
									<i class="em em-angry"></i>
									<i class="em em-astonished"></i>
									<i class="em em-blush"></i>
									<i class="em em-disappointed"></i>
									<i class="em em-worried"></i>
									<i class="em em-kissing_heart"></i>
									<i class="em em-rage"></i>
									<i class="em em-stuck_out_tongue"></i>
								</div>
							</div>

							<button type="submit"></button>
						</form>	
					</div>
					<figure><img src="images/resources/share-post.jpg" alt=""></figure>
					<div class="friend-info">
						<figure>
							<img alt="" src="images/resources/admin.jpg">
						</figure>
						<div class="friend-name">
							<ins><a title="" href="time-line.html">Jack Carter</a> share <a title="" href="#">link</a></ins>
							<span>Yesterday with @Jack Piller and @Emily Stone at the concert of # Rock'n'Rolla in Ontario.</span>
						</div>
					</div>
					<div class="share-to-other">
						<span>Share to other socials</span>
						<ul>
							<li><a class="facebook-color" href="#" title=""><i class="fa fa-facebook-square"></i></a></li>
							<li><a class="twitter-color" href="#" title=""><i class="fa fa-twitter-square"></i></a></li>
							<li><a class="dribble-color" href="#" title=""><i class="fa fa-dribbble"></i></a></li>
							<li><a class="instagram-color" href="#" title=""><i class="fa fa-instagram"></i></a></li>
							<li><a class="pinterest-color" href="#" title=""><i class="fa fa-pinterest-square"></i></a></li>
						</ul>
					</div>
					<div class="copy-email">
						<span>Copy & Email</span>
						<ul>
							<li><a href="#" title="Copy Post Link"><i class="fa fa-link"></i></a></li>
							<li><a href="#" title="Email this Post"><i class="fa fa-envelope"></i></a></li>
						</ul>
					</div>
					<div class="we-video-info">
						<ul>
							<li>
								<span title="" data-toggle="tooltip" class="views" data-original-title="views">
									<i class="fa fa-eye"></i>
									<ins>1.2k</ins>
								</span>
							</li>
							<li>
								<span title="" data-toggle="tooltip" class="views" data-original-title="views">
									<i class="fa fa-share-alt"></i>
									<ins>20k</ins>
								</span>
							</li>
						</ul>
						<button class="main-btn color" data-ripple="">Submit</button>
						<button class="main-btn cancel" data-ripple="">Cancel</button>
					</div>
				</div>
			</div>	
		</div>
	</div><!-- share popup -->
	
	<div class="popup-wraper3">
		<div class="popup">
			<span class="popup-closed"><i class="ti-close"></i></span>
			<div class="popup-meta">
				<div class="popup-head">
					<h5>Report Post</h5>
				</div>
				<div class="Rpt-meta">
					<span>We're sorry something's wrong. How can we help?</span>
					<form method="post" class="c-form">
						<div class="form-radio">
						  <div class="radio">
							<label>
							  <input type="radio" name="radio" checked="checked"><i class="check-box"></i>It's spam or abuse
							</label>
						  </div>
						  <div class="radio">
							<label>
							  <input type="radio" name="radio"><i class="check-box"></i>It breaks r/technology's rules
							</label>
						  </div>
							<div class="radio">
							<label>
							  <input type="radio" name="radio"><i class="check-box"></i>Not Related
							</label>
						  </div>
							<div class="radio">
							<label>
							  <input type="radio" name="radio"><i class="check-box"></i>Other issues
							</label>
						  </div>
						</div>
					<div>
						<label>Write about Report</label>
						<textarea placeholder="write someting about Post" rows="2"></textarea>
					</div>
					<div>
						<button data-ripple="" type="submit" class="main-btn">Submit</button>
						<a href="#" data-ripple="" class="main-btn3 cancel">Close</a>
					</div>
					</form>	
				</div>
			</div>	
		</div>
	</div><!-- report popup -->
	
	<div class="popup-wraper4">
		<div class="popup creat-group">
			<span class="popup-closed"><i class="ti-close"></i></span>
			<div class="popup-meta">
				<div class="popup-head">
					<h5>Create Friend Group</h5>
				</div>
				<div class="group-adding">
					<div class="friend-group">
						
						<div class="change-photo">
							<figure><img src="images/resources/admin2.jpg" alt=""></figure>
							<div class="edit-img">
								<form class="edit-phto">
									<label class="fileContainer">
										<i class="fa fa-camera-retro"></i>
										Upload Group Avatar
									<input type="file">
									</label>
								</form>
							</div>
						</div>
						<form method="post">
							<input type="text" placeholder="Group Name">
							<input type="text" placeholder="Category">
							<select>
								<option value="Select">Select</option>
								<option value="">Family front</option>
								<option value="">Gold Mines Group</option>
								<option value="">Friends Family</option>
								<option value="">Creative world</option>
							</select>
							<button class="main-btn">Create Group</button>
						</form>
					</div>
				</div>
			</div>
		</div>
	</div><!-- Create friends Group -->
	
	<div class="popup-wraper5">
		<div class="popup">
			<span class="popup-closed"><i class="ti-close"></i></span>
			<div class="popup-meta">
				<div class="popup-head">
					<h5>Upload Pictures & Videos</h5>
				</div>
				<div class="upload-boxes">
					<div class="row">
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="smal-box">
								<label class="fileContainer">
									<i class=" ti-layout-media-center-alt"></i>
									<input type="file">
									<em>Upload New</em>
									<span>Choose form Computer</span>
								</label>
							</div>
						</div>
						<div class="col-lg-6 col-md-6 col-sm-6">
							<div class="smal-box">
								<div class="from-gallery">
									<i class="ti-layout-grid2"></i>
									<em>From Gallery Or Album</em>
									<span>Choose form already uploaded</span>
								</div>
							</div>
						</div>
					</div>
					<div class="sugested-photos">
						<h5>Suggested Photos & Videos <a href="#" title="">See All</a></h5>
						<ul class="sugestd-photo-caro">
							<li><img src="images/resources/sug1.jpg" alt=""></li>
							<li><img src="images/resources/sug2.jpg" alt=""></li>
							<li><img src="images/resources/sug3.jpg" alt=""></li>
							<li><img src="images/resources/sug4.jpg" alt=""></li>
							<li><img src="images/resources/sug5.jpg" alt=""></li>
						</ul>
					</div>
					<a class="main-btn" href="#" title="" data-ripple="">Proceed</a>
				</div>
			</div>
		</div>
		<div class="already-gallery">
			<div class="popup-head">
				<h5>Choose from gallery</h5>
			</div>
			<ul class="sugestd-photo-caro">
				<li><img src="images/resources/sug1.jpg" alt=""></li>
				<li><img src="images/resources/sug2.jpg" alt=""></li>
				<li><img src="images/resources/sug3.jpg" alt=""></li>
				<li><img src="images/resources/sug4.jpg" alt=""></li>
				<li><img src="images/resources/sug5.jpg" alt=""></li>
				<li><img src="images/resources/sug6.jpg" alt=""></li>
				<li><img src="images/resources/sug7.jpg" alt=""></li>
				<li><img src="images/resources/sug4.jpg" alt=""></li>
				<li><img src="images/resources/sug1.jpg" alt=""></li>
				<li><img src="images/resources/sug2.jpg" alt=""></li>
				<li><img src="images/resources/sug4.jpg" alt=""></li>
				<li><img src="images/resources/sug5.jpg" alt=""></li>
				<li><img src="images/resources/sug6.jpg" alt=""></li>
				<li><img src="images/resources/sug7.jpg" alt=""></li>
				<li><img src="images/resources/sug1.jpg" alt=""></li>
				<li><img src="images/resources/sug4.jpg" alt=""></li>
				<li><img src="images/resources/sug5.jpg" alt=""></li>
			</ul>
			<a class="main-btn" href="#" title="" data-ripple="">Confirm</a>
			<a class="main-btn canceld" href="#" title="" data-ripple="">Cancel</a>
		</div>
	</div><!-- upload Pictures / album popup -->
	
	<div class="popup-wraper6">
		<div class="popup login">
			<span class="popup-closed"><i class="ti-close"></i></span>
			<div class="popup-meta">
				<div class="popup-head">
					<h5><i class="ti-key"></i> Login to Pitnik</h5>
				</div>
				<div class="login-frm">
					<input type="text" placeholder="User Name">
					<input type="password" placeholder="Password">
					<div class="checkbox">
					  <label>
						<input type="checkbox" checked="checked"><i class="check-box"></i>Remember Password
					  </label>
					</div>
					<button data-ripple="" type="submit" class="main-btn">Login</button>
					<a href="#" title="">Forgotten password?</a>
				</div>
			</div>
		</div>
	</div><!-- login popup -->
	
	<div class="call-wraper">
		<div class="m-live-call">
			<figure><img src="images/resources/author.jpg" alt=""></figure>
			<div class="call-box">
				<h6>Jack Carter</h6>
				<span>incoming call</span>
				<i class="ti-microphone"></i>
				<div class="wave">
					<span class="dot"></span>
					<span class="dot"></span>
					<span class="dot"></span>
				</div>
				<ins class="later-rmnd">Remind me later</ins>
				<div class="yesorno">
					<a class="bg-blue accept-call" href="#" title=""><i class="fa fa-phone"></i></a>
					<a class="bg-red decline-call" href="#" title=""><i class="fa fa-close"></i></a>
				</div>
			</div>
		</div>
	</div><!-- audio video call popup -->
	
	<div class="popup-wraper7">
		<div class="popup events">
			<span class="popup-closed"><i class="ti-close"></i></span>
			<div class="popup-meta">
				<div class="popup-head">
					<h5></h5>
				</div>
				<div class="event-detail">
					<figure><img src="images/resources/event-detail1.jpg" alt=""></figure>
					<div class="event-detailmeta">
						<h4>Ocean Motel good night event in columbia for the youngests only.</h4>
						<p>
							Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat. Duis aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum.
						</p>
						<div class="location-map">
							<span>Venu Location</span>
							<p>Confrence Hall street 34 lasal Ontario, Canada.</p>
							<div id="map-canvas"></div>
						</div>
						<a class="main-btn event" href="#" title="">Add Calendar</a>
						<a class="main-btn event" href="#" title="">Invite Friends</a>
					</div>
				</div>
			</div>
		</div>
	</div><!-- Event detail Popup -->
	
	<div class="modal fade" id="img-comt">
		<div class="modal-dialog">
		  <div class="modal-content">

			<!-- Modal Header -->
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal">×</button>
			</div>

			<!-- Modal body -->
			<div class="modal-body">
				<div class="row">
					<div class="col-lg-8">
						<div class="pop-image">
							<div class="pop-item">
								<figure><img src="images/resources/blog-detail.jpg" alt=""></figure>
							</div>
						</div>
					</div>
					<div class="col-lg-4">
						<div class="user">
							<figure><img src="images/resources/user1.jpg" alt=""></figure>
							<div class="user-information">
								<h4><a href="#" title="">Danile Walker</a></h4>
								<span>2 hours ago</span>
							</div>
							<a href="#" title="Follow" data-ripple="">Follow</a>
						</div>
						<div class="we-video-info">
							<ul>
								<li>
									<div title="Like/Dislike" class="likes heart">❤ <span>2K</span></div>
								</li>
								<li>
									<span title="Comments" class="comment">
										<i class="fa fa-commenting"></i>
										<ins>52</ins>
									</span>
								</li>

								<li>
									<span>
										<a title="Share" href="#" class="">
											<i class="fa fa-share-alt"></i>
										</a>
										<ins>20</ins>
									</span>	
								</li>
							</ul>
							<div class="users-thumb-list">
								<a href="#" title="" data-toggle="tooltip" data-original-title="Anderw">
									<img src="images/resources/userlist-1.jpg" alt="">  
								</a>
								<a href="#" title="" data-toggle="tooltip" data-original-title="frank">
									<img src="images/resources/userlist-2.jpg" alt="">  
								</a>
								<a href="#" title="" data-toggle="tooltip" data-original-title="Sara">
									<img src="images/resources/userlist-3.jpg" alt="">  
								</a>
								<a href="#" title="" data-toggle="tooltip" data-original-title="Amy">
									<img src="images/resources/userlist-4.jpg" alt="">  
								</a>
								<span><strong>You</strong>, <b>Sarah</b> and <a title="" href="#">24+ more</a> liked</span>
							</div>
						</div>
						<div style="display: block;" class="coment-area">
							<ul class="we-comet">
								<li>
									<div class="comet-avatar">
										<img alt="" src="images/resources/nearly3.jpg">
									</div>
									<div class="we-comment">
										<h5><a title="" href="time-line.html">Jason borne</a></h5>
										<p>we are working for the dance and sing songs. this video is very awesome for the youngster. please vote this video and like our channel</p>
										<div class="inline-itms">
											<span>1 year ago</span>
											<a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
											<a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
										</div>
									</div>

								</li>
								<li>
									<div class="comet-avatar">
										<img alt="" src="images/resources/comet-4.jpg">
									</div>
									<div class="we-comment">
										<h5><a title="" href="time-line.html">Sophia</a></h5>
										<p>we are working for the dance and sing songs. this video is very awesome for the youngster.
											<i class="em em-smiley"></i>
										</p>
										<div class="inline-itms">
											<span>1 year ago</span>
											<a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
											<a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
										</div>
									</div>
								</li>
								<li>
									<div class="comet-avatar">
										<img alt="" src="images/resources/comet-4.jpg">
									</div>
									<div class="we-comment">
										<h5><a title="" href="time-line.html">Sophia</a></h5>
										<p>we are working for the dance and sing songs. this video is very awesome for the youngster.
											<i class="em em-smiley"></i>
										</p>
										<div class="inline-itms">
											<span>1 year ago</span>
											<a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
											<a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
										</div>
									</div>
								</li>
								<li>
									<a class="showmore underline" title="" href="#">more comments+</a>
								</li>
								<li class="post-comment">
									<div class="comet-avatar">
										<img alt="" src="images/resources/nearly1.jpg">
									</div>
									<div class="post-comt-box">
										<form method="post">
											<textarea placeholder="Post your comment"></textarea>
											<div class="add-smiles">
												<div class="uploadimage">
													<i class="fa fa-image"></i>
													<label class="fileContainer">
														<input type="file">
													</label>
												</div>
												<span title="add icon" class="em em-expressionless"></span>
												<div class="smiles-bunch">
													<i class="em em---1"></i>
													<i class="em em-smiley"></i>
													<i class="em em-anguished"></i>
													<i class="em em-laughing"></i>
													<i class="em em-angry"></i>
													<i class="em em-astonished"></i>
													<i class="em em-blush"></i>
													<i class="em em-disappointed"></i>
													<i class="em em-worried"></i>
													<i class="em em-kissing_heart"></i>
													<i class="em em-rage"></i>
													<i class="em em-stuck_out_tongue"></i>
												</div>
											</div>

											<button type="submit"></button>
										</form>	
									</div>
								</li>
							</ul>
						</div>
					</div>
				</div>
			</div>
		  </div>
		</div>
    </div><!-- The Scrolling Modal image with comment -->
	
	<div class="modal fade" id="blog-popup">
		<div class="modal-dialog">
		  <div class="modal-content">

			<!-- Modal Header -->
			<div class="modal-header">
			  <button type="button" class="close" data-dismiss="modal">×</button>
			</div>

			<!-- Modal body -->
			<div class="modal-body">
				<div class="blog-popup-meta">
					<div class="pop-image">
						<div class="pop-item">
							<figure><img src="images/resources/blog-detail.jpg" alt=""></figure>
						</div>
					</div>
					<div class="user">
						<figure><img src="images/resources/user1.jpg" alt=""></figure>
						<div class="user-information">
							<h4><a href="#" title="">Danile Walker</a></h4>
							<span>2 hours ago</span>
						</div>
						<a href="#" title="Follow" data-ripple="">Follow</a>
					</div>
					<div class="we-video-info">
						<ul>
							<li>
								<div title="Like/Dislike" class="likes heart">❤ <span>2K</span></div>
							</li>
							<li>
								<span title="Comments" class="comment">
									<i class="fa fa-commenting"></i>
									<ins>52</ins>
								</span>
							</li>

							<li>
								<span>
									<a title="Share" href="#" class="">
										<i class="fa fa-share-alt"></i>
									</a>
									<ins>20</ins>
								</span>	
							</li>
						</ul>
						<div class="users-thumb-list">
							<a href="#" title="" data-toggle="tooltip" data-original-title="Anderw">
								<img src="images/resources/userlist-1.jpg" alt="">  
							</a>
							<a href="#" title="" data-toggle="tooltip" data-original-title="frank">
								<img src="images/resources/userlist-2.jpg" alt="">  
							</a>
							<a href="#" title="" data-toggle="tooltip" data-original-title="Sara">
								<img src="images/resources/userlist-3.jpg" alt="">  
							</a>
							<a href="#" title="" data-toggle="tooltip" data-original-title="Amy">
								<img src="images/resources/userlist-4.jpg" alt="">  
							</a>
							<span><strong>You</strong>, <b>Sarah</b> and <a title="" href="#">24+ more</a> liked</span>
						</div>
					</div>
					<div class="blog-paragraph">
						<h4>How to Write a Blog Post: A Step-by-Step Guide</h4>
						<p>
							Lorem ipsum dolor sit amet, consectadipisicing elit, sed do eiusmod por incidid ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud lorem exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
						</p>
						<p>
							Duis en aute irure dolor in reprehenderit in voluptate velit esse cillum dolore eu fugiat nulla pariatur. Excepteur sint occaecat cupidatat non proident, sunt in culpa qui officia deserunt mollit anim id est laborum. Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi hitecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt Sed ut perspiciatis unde omnis iste natus error sit voluptatem accusantium doloremque laudantium, totam rem aperiam, eaque ipsa quae ab illo inventore veritatis et quasi architecto beatae vitae dicta sunt explicabo. Nemo enim ipsam voluptatem quia voluptas sit aspernatur aut odit aut fugit, sed quia consequuntur magni dolores eos qui ratione voluptatem sequi nesciunt.
						</p>
					</div>
					<div style="display: block;" class="coment-area">
						<ul class="we-comet">
							<li>
								<div class="comet-avatar">
									<img alt="" src="images/resources/nearly3.jpg">
								</div>
								<div class="we-comment">
									<h5><a title="" href="time-line.html">Jason borne</a></h5>
									<p>we are working for the dance and sing songs. this video is very awesome for the youngster. please vote this video and like our channel</p>
									<div class="inline-itms">
										<span>1 year ago</span>
										<a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
										<a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
									</div>
								</div>

							</li>
							<li>
								<div class="comet-avatar">
									<img alt="" src="images/resources/comet-4.jpg">
								</div>
								<div class="we-comment">
									<h5><a title="" href="time-line.html">Sophia</a></h5>
									<p>we are working for the dance and sing songs. this video is very awesome for the youngster.
										<i class="em em-smiley"></i>
									</p>
									<div class="inline-itms">
										<span>1 year ago</span>
										<a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
										<a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
									</div>
								</div>
							</li>
							<li>
								<div class="comet-avatar">
									<img alt="" src="images/resources/comet-4.jpg">
								</div>
								<div class="we-comment">
									<h5><a title="" href="time-line.html">Sophia</a></h5>
									<p>we are working for the dance and sing songs. this video is very awesome for the youngster.
										<i class="em em-smiley"></i>
									</p>
									<div class="inline-itms">
										<span>1 year ago</span>
										<a title="Reply" href="#" class="we-reply"><i class="fa fa-reply"></i></a>
										<a title="" href="#"><i class="fa fa-heart"></i><span>20</span></a>
									</div>
								</div>
							</li>
							<li>
								<a class="showmore underline" title="" href="#">more comments+</a>
							</li>
							<li class="post-comment">
								<div class="comet-avatar">
									<img alt="" src="images/resources/nearly1.jpg">
								</div>
								<div class="post-comt-box">
									<form method="post">
										<textarea placeholder="Post your comment"></textarea>
										<div class="add-smiles">
											<div class="uploadimage">
												<i class="fa fa-image"></i>
												<label class="fileContainer">
													<input type="file">
												</label>
											</div>
											<span title="add icon" class="em em-expressionless"></span>
											<div class="smiles-bunch">
												<i class="em em---1"></i>
												<i class="em em-smiley"></i>
												<i class="em em-anguished"></i>
												<i class="em em-laughing"></i>
												<i class="em em-angry"></i>
												<i class="em em-astonished"></i>
												<i class="em em-blush"></i>
												<i class="em em-disappointed"></i>
												<i class="em em-worried"></i>
												<i class="em em-kissing_heart"></i>
												<i class="em em-rage"></i>
												<i class="em em-stuck_out_tongue"></i>
											</div>
										</div>

										<button type="submit"></button>
									</form>	
								</div>
							</li>
						</ul>
					</div>
				</div>
			</div>
		  </div>
		</div>
    </div><!-- blog post detail-->
	
	<div class="modal fade" id="faq-popup">
		<div class="modal-dialog">
		  <div class="modal-content">

			<!-- Modal Header -->
			<div class="modal-header">
			  <h5 class="modal-title">Ask help about Pitnik</h5>
			  <button type="button" class="close" data-dismiss="modal">&times;</button>
			</div>

			<!-- Modal body -->
			<div class="modal-body">
			  <div class="faq-area">
					<p>
						Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
					</p>
					<div class="accordion" id="accordion">
					  <div class="card">
						<div class="card-header" id="headingOne">
						  <h5 class="mb-0">
							<button class="btn btn-link" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
							  How to make your own social website ?
							</button>
						  </h5>
						</div>

						<div id="collapseOne" class="collapse show" aria-labelledby="headingOne" data-parent="#accordion">
						  <div class="card-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod.
							  <a href="#" title="">Go for Create Page</a>
							<ol>
								<li>register yourself on friendzone</li>
								<li>go to the setting panal</li>
								<li>click on <a href="#" title="">create page</a></li>
							</ol>
						  </div>
						</div>
					  </div>
					  <div class="card">
						<div class="card-header" id="headingTwo">
						  <h5 class="mb-0">
							<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseTwo" aria-expanded="false" aria-controls="collapseTwo">
							  How to edit my page setting?
							</button>
						  </h5>
						</div>
						<div id="collapseTwo" class="collapse" aria-labelledby="headingTwo" data-parent="#accordion">
						  <div class="card-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, 
						  </div>
						</div>
					  </div>
					  <div class="card">
						<div class="card-header" id="headingThree">
						  <h5 class="mb-0">
							<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapseThree" aria-expanded="false" aria-controls="collapseThree">
							  How to change password ?
							</button>
						  </h5>
						</div>
						<div id="collapseThree" class="collapse" aria-labelledby="headingThree" data-parent="#accordion">
						  <div class="card-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. 
						  </div>
						</div>
					  </div>
					  <div class="card">
						<div class="card-header" id="headingfour">
						  <h5 class="mb-0">
							<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefour" aria-expanded="false" aria-controls="collapsefour">
							  How to search people nearby with location ?
							</button>
						  </h5>
						</div>
						<div id="collapsefour" class="collapse" aria-labelledby="headingfour" data-parent="#accordion">
						  <div class="card-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. 
						  </div>
						</div>
					  </div>
					  <div class="card">
						<div class="card-header" id="headingfive">
						  <h5 class="mb-0">
							<button class="btn btn-link collapsed" type="button" data-toggle="collapse" data-target="#collapsefive" aria-expanded="false" aria-controls="collapsefive">
							  How to Make your favourit page ?
							</button>
						  </h5>
						</div>
						<div id="collapsefive" class="collapse" aria-labelledby="headingfive" data-parent="#accordion">
						  <div class="card-body">
							Anim pariatur cliche reprehenderit, enim eiusmod high life accusamus terry richardson ad squid. 3 wolf moon officia aute, non cupidatat skateboard dolor brunch. Food truck quinoa nesciunt laborum eiusmod. Brunch 3 wolf moon tempor, sunt aliqua put a bird on it squid single-origin coffee nulla assumenda shoreditch et. 
						  </div>
						</div>
					  </div>
					</div>
				</div>
			</div>

			<!-- Modal footer -->
			<div class="modal-footer">
			  <button type="button" class="btn" data-dismiss="modal">Close</button>
			</div>
		  </div>
		</div>
	</div><!-- fade Modal -->
	
	<script src="js/main.min.js"></script>
	<script src="https://maps.googleapis.com/maps/api/js?key=AIzaSyA8c55_YHLvDHGACkQscgbGLtLRdxBDCfI"></script>
	<script src="js/locationpicker.jquery.js"></script>
	<script src="js/map-init.js"></script>
	<script src="js/script.js"></script>
	<script>
		jQuery(document).ready(function($) {
			
			$('#us3').locationpicker({
			  location: {
			    latitude: -8.681013,
			    longitude: 115.23506410000005
			  },
			  radius: 0,
			  inputBinding: {
			    latitudeInput: $('#us3-lat'),
			    longitudeInput: $('#us3-lon'),
			    radiusInput: $('#us3-radius'),
			    locationNameInput: $('#us3-address')
			  },
			  enableAutocomplete: true,
			  onchanged: function (currentLocation, radius, isMarkerDropped) {
			    // Uncomment line below to show alert on each Location Changed event
			    //alert("Location changed. New location (" + currentLocation.latitude + ", " + currentLocation.longitude + ")");
			  }
			});

		});	
</script>

</body>	
</html>